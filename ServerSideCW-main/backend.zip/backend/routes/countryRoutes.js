const express = require('express');
const jwt = require('jsonwebtoken');
const countryController = require('../controllers/countryController');

const router = express.Router();

function authenticateToken(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ message: 'No token provided' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ message: 'Invalid token' });
  }
}

router.get('/', authenticateToken, countryController.getAllCountries);
router.get('/:name', authenticateToken, countryController.getCountryByName);

module.exports = router;